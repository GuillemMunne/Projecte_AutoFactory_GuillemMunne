﻿using System.Windows;

namespace ProjecteAutoFactory
{
    /// <summary>
    /// Lógica de interacción para App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}

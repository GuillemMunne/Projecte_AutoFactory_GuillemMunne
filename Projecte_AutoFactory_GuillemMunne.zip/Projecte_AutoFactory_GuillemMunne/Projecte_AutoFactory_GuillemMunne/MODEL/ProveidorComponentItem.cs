﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projecte_AutoFactory_GuillemMunne.MODEL
{
    public class ProveidorComponentItem
    {
        public int CodiProveidor { get; set; }
        public string NomProveidor { get; set; }
        public decimal Preu { get; set; }
    }

}

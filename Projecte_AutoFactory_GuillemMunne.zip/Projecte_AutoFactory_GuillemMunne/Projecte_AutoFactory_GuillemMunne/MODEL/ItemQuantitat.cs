﻿using AutoFactory.Model;
using System.ComponentModel;

namespace AutoFactory.Model
{

    public class ItemQuantitat : INotifyPropertyChanged
    {
        public Item Item { get; }

        public string Nom => Item.Nom;

        private int _quantitat;
        public int Quantitat
        {
            get => _quantitat;
            set
            {
                if (_quantitat != value)
                {
                    _quantitat = value;
                    PropertyChanged?.Invoke(
                        this,
                        new PropertyChangedEventArgs(nameof(Quantitat))
                    );
                }
            }
        }

        public ItemQuantitat(Item item)
        {
            Item = item;
            Quantitat = 0;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
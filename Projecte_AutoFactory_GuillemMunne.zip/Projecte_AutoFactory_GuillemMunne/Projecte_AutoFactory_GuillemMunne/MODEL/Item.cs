using System;

namespace AutoFactory.Model
{
    public abstract class Item
    {
        public static int CODI_VALID;
        private int codi;
        private string nom;
        private string descripcio;
        private int stock;
        private byte[] foto;

        public Item() {  }

        public Item(int codi, string nom, string descripcio, int stock, byte[] foto)
        {
            this.codi = codi;
            this.nom = nom;
            this.descripcio = descripcio;
            this.stock = stock;
            this.foto = foto;
            Item.CODI_VALID++;
        }

        public int Codi { get => codi; set => codi = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Descripcio { get => descripcio; set => descripcio = value; }
        public int Stock { get => stock; set => stock = value; }
        public byte[] Foto { get => foto; set => foto = value; }

        public override bool Equals(object? obj)
        {
            if (obj is not Item other)
                return false;

            return Codi == other.Codi;
        }

        public override int GetHashCode()
        {
            return Codi.GetHashCode();
        }

    }
}
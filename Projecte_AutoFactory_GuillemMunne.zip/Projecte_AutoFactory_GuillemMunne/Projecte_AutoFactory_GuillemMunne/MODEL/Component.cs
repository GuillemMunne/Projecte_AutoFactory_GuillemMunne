using Projecte_AutoFactory_GuillemMunne.MODEL;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace AutoFactory.Model
{
    

    public class Component : Item
    {
        private int _codi_fabricant;
        private decimal _preu_mig;
        private UnitatMesura _unitat;
        private List<ProveidorComponentItem> _proveidors;
        public override string ToString()
        {
            return Nom;
        }
        public void BuidaProveidors()
        {
            _proveidors.Clear();
            PreuMig = 0;
        }

        public int CodiFabricant
        {
            get { return _codi_fabricant; }
            set { _codi_fabricant = value; }
        }

        public decimal PreuMig
        {
            get { return _preu_mig; }
            set { _preu_mig = value; }
        }

        public UnitatMesura Unitat
        {
            get { return _unitat; }
            set { _unitat = value; }
        }


        public Component()
        {
            _proveidors = new List<ProveidorComponentItem>();
        }

        ~Component()
        {
        }

        public void afegirProveidor(ProveidorComponentItem proveidor)
        {
            _proveidors.Add(proveidor);
            actualitzarPreuMig();
        }

        private void actualitzarPreuMig()
        {
            if (_proveidors.Count > 0)
                foreach (var proveidor in _proveidors)
                {
                    PreuMig += proveidor.Preu;
                }
            PreuMig /= _proveidors.Count;
        }

        //public void modificarProveidorPreu(Proveidor proveidor, decimal preu)
        //{
        //    if (_proveidors.ContainsKey(proveidor))
        //    {
        //        _proveidors[proveidor] = preu;
        //        actualitzarPreuMig();
        //    }
        //}

        public ReadOnlyCollection<ProveidorComponentItem> ObtenirProveidors()
        {
            return new ReadOnlyCollection<ProveidorComponentItem>(_proveidors);
        }



    }
}

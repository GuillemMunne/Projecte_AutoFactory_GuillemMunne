using System;
using System.Collections.Generic;

namespace AutoFactory.Model
{
    public class UnitatMesura
    {
        private int codi;
        private string nom;

        public UnitatMesura(int codi, string nom)
        {
            this.codi = codi;
            this.nom = nom;
        }

        public int Codi => codi;
        public string Nom => nom;
    }

}

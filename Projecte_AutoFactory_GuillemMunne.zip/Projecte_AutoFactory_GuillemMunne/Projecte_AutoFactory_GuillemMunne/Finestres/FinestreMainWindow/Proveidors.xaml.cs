﻿using AutoFactory.DAO;
using AutoFactory.Model;
using System.Collections.Generic;
using System.Windows.Controls;

namespace ProjecteAutoFactory.Finestres.FinestreMainWindow
{
    public partial class Proveidors : UserControl
    {
        private ProveidorDao _proveidorDao;
        private DAOComponent _componentDao;

        private List<Proveidor> _proveidors = new();
        private List<Component> _components = new();


        public Proveidors(ProveidorDao proveidorDao, DAOComponent componentDao)
        {
            InitializeComponent();

            _proveidorDao = proveidorDao;
            _componentDao = componentDao;

            CarregarProveidors();
        }

        private void CarregarProveidors()
        {
            _proveidors = _proveidorDao.ObtenirTots();
            lbProveidors.ItemsSource = _proveidors;
        }

        private void lbProveidors_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbProveidors.SelectedItem is not Proveidor prov)
                return;

            _components = new List<Component>();
            _components.Clear();

            List<int> codisComponents =
                _componentDao.ObtenirCodiComponentPerProveidor(prov.GetCodi());

            foreach (int codi in codisComponents)
            {
                Component comp = _componentDao.ObtenirComponent(codi);
                if (comp != null)
                    _components.Add(comp);
            }

            lbProductesProveidor.ItemsSource = _components;
        }



        private void tbCercaProveidor_TextChanged(object sender, TextChangedEventArgs e)
        {
            string text = tbCercaProveidor.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(text))
            {
                lbProveidors.ItemsSource = _proveidors;
                return;
            }

            lbProveidors.ItemsSource = _proveidors
                .Where(p => p.Nom != null && p.Nom.ToLower().Contains(text))
                .ToList();
        }



        private void tbCercaComponentProveidor_TextChanged(object sender, TextChangedEventArgs e)
        {
            string text = tbCercaComponentProveidor.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(text))
            {
                lbProductesProveidor.ItemsSource = _components;
                return;
            }

            lbProductesProveidor.ItemsSource = _components
                .Where(c => c.Nom != null && c.Nom.ToLower().Contains(text))
                .ToList();
        }




    }
}

﻿using AutoFactory.DAO;
using AutoFactory.Model;
using Projecte_AutoFactory_GuillemMunne.Finestres.FinestreNormal;
using ProjecteAutoFactory.Clases;
using ProjecteAutoFactory.Finestres.FinestreNormal;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ProjecteAutoFactory.Finestres.FinestreMainWindow
{
    /// <summary>
    /// Lógica de interacción para GestioProductes.xaml
    /// </summary>
    public partial class GestioProductes : UserControl
    {
        private ProducteDao _producteDao;
        private DAOComponent _componentDao;
        private List<Producte> _totsElsProductes;



        public GestioProductes(ProducteDao producteDao, DAOComponent componentDao)
        {
            InitializeComponent();

            _producteDao = producteDao;
            _componentDao = componentDao;

            _totsElsProductes = _producteDao.ObtenirTots().ToList();
            List<Item> items = new List<Item>();
            items.AddRange(_totsElsProductes);
            items.AddRange(_componentDao.ObtenirTots());
            Item.CODI_VALID = items.Count + 1;
            tbLlistaProductes.ItemsSource = _totsElsProductes;
        }


        #region GestioProductes;


        private void ObrirAfegirProducte_Click(object sender, RoutedEventArgs e)
        {
            var finestra = new AfegirElProducte(_producteDao, _componentDao)
            {
                Owner = Window.GetWindow(this)
            };

            if (finestra.ShowDialog() == true && finestra.NouProducte != null)
            {
                _producteDao.AfegirProducte(finestra.NouProducte);
                _producteDao.ValidarCanvis();

                _totsElsProductes = _producteDao.CarregarProductes();
                tbLlistaProductes.ItemsSource = _totsElsProductes;
                tbArbreDomProductes.Items.Clear();
            }
        }




        private void tbCercaProducte_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_totsElsProductes == null || _totsElsProductes.Count == 0)
                return;

            string text = tbCercaProducte.Text.Trim();

            // 🔹 Sense text → tots
            if (string.IsNullOrEmpty(text))
            {
                tbLlistaProductes.ItemsSource = _totsElsProductes;
                return;
            }

            // 🔹 Número → codi exacte
            if (int.TryParse(text, out int codi))
            {
                tbLlistaProductes.ItemsSource = _totsElsProductes
                    .Where(p => p.Codi == codi)
                    .ToList();
                return;
            }

            string textLower = text.ToLower();

            var filtrats = _totsElsProductes
                .Where(p => !string.IsNullOrEmpty(p.Nom) &&
                            p.Nom
                             .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                             .Any(paraula => paraula.StartsWith(textLower, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            tbLlistaProductes.ItemsSource = filtrats;
        }



        /*   private void tbCercaProducte_LostFocus(object sender, RoutedEventArgs e)
           {
               busquedaProducte(sender, e);
           }


        */

        private void tbLlistaProductes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            actualitzarDescripcioProducte();
            actualitzarArbreDom();
           
        }
        private void actualitzarArbreDom()
        {
            tbArbreDomProductes.Items.Clear();

            if (tbLlistaProductes.SelectedItem is not Producte producte)
            {
                tbArbreDomProductes.Items.Add(
                    new TreeViewItem
                    {
                        Header = "Selecciona un producte per veure l'arbre DOM."
                    });
                return;
            }

            var nodeArrel = CrearNodeProducte(producte);
            tbArbreDomProductes.Items.Add(nodeArrel);
        }


        private TreeViewItem CrearNodeProducte(Producte producte)
        {
            var node = new TreeViewItem
            {
                Header = producte.Nom,
                Tag = producte,
                IsExpanded = true
            };

            foreach (var kv in producte.Conte)
            {
                var item = kv.Key;
                var quantitat = kv.Value;

                node.Items.Add(CrearNodeItem(item, quantitat));
            }

            return node;
        }


        private TreeViewItem CrearNodeItem(Item item, int quantitat)
        {
            // 🔑 Si és component i no té nom → el rehidratem
            if (item is Component c && string.IsNullOrWhiteSpace(c.Nom))
            {
                var complet = _componentDao.ObtenirComponent(c.Codi);
                if (complet != null)
                    item = complet;
            }

            var header = $"{item.Nom} x{quantitat}";

            var node = new TreeViewItem
            {
                Header = header,
                Tag = item,
                IsExpanded = true
            };

            // Si algun dia tens subproductes recursius
            if (item is Producte p && p.Conte.Count > 0)
            {
                foreach (var kv in p.Conte)
                    node.Items.Add(CrearNodeItem(kv.Key, kv.Value));
            }

            return node;
        }






        private void actualitzarDescripcioProducte()
        {
            Producte producteSeleccionat = (Producte)tbLlistaProductes.SelectedItem;

            if (producteSeleccionat != null)
            {
                tbDetallProducte.Content = "Descripció: " + producteSeleccionat.Descripcio;
            }
            else
            {
                tbDetallProducte.Content = "Selecciona un producte per veure la descripció.";
            }
        }



        private void busquedaProducte(object sender, RoutedEventArgs e)
        {
            string textCercat = tbCercaProducte.Text.Trim();

            // Si està buit, restaurem la llista completa i sortim sense missatge
            if (string.IsNullOrEmpty(textCercat))
            {
                tbLlistaProductes.ItemsSource = Productes.LlistaProductes;
                return;
            }

            HashSet<Productes> resultats = new HashSet<Productes>();

            foreach (var p in Productes.LlistaProductes)
            {
                bool nomCoincide = p.Nom.StartsWith(textCercat, StringComparison.OrdinalIgnoreCase);
                bool codiCoincide = p.Codi.ToString().StartsWith(textCercat, StringComparison.OrdinalIgnoreCase);

                if (nomCoincide || codiCoincide)
                {
                    resultats.Add(p);
                }
            }

            if (resultats.Count == 0)
            {
                MessageBox.Show("No s'han trobat resultats.", "Sense coincidències", MessageBoxButton.OK, MessageBoxImage.Information);
                tbLlistaProductes.ItemsSource = null;
            }
            else
            {
                tbLlistaProductes.ItemsSource = resultats;
                MessageBox.Show($"S'han trobat {resultats.Count} productes que coincideixen amb la cerca.",
                    "Resultats de la cerca", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }



        private void ModificarProducte_Click(object sender, RoutedEventArgs e)
        {
            if (tbLlistaProductes.SelectedItem is not Producte producteSeleccionat)
            {
                MessageBox.Show("Si us plau, selecciona un producte per modificar.",
                                "Error: Cap producte seleccionat",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                return;
            }

            var finestra = new AfegirElProducte(_producteDao, _componentDao, producteSeleccionat)
            {
                Owner = Window.GetWindow(this)
            };

            if (finestra.ShowDialog() == true && finestra.NouProducte != null)
            {
                _producteDao.ModificarProducte(finestra.NouProducte);
                _producteDao.ValidarCanvis();
                _totsElsProductes = _producteDao.CarregarProductes();
                tbLlistaProductes.ItemsSource = _totsElsProductes;
                tbLlistaProductes.Items.Refresh();
                actualitzarDescripcioProducte();
                actualitzarArbreDom();
            }
        }


        private void EliminarProducte(object sender, RoutedEventArgs e)
        {
            // Comprova que hi hagi un producte seleccionat
            if (tbLlistaProductes.SelectedItem is not Producte producteSeleccionat)
            {
                MessageBox.Show(
                    "Si us plau, selecciona un producte per eliminar.",
                    "Error: Cap producte seleccionat",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            // Demana confirmació
            var resultat = MessageBox.Show(
                $"Estàs segur que vols eliminar el producte {producteSeleccionat.Nom}?",
                "Confirmar eliminació",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultat != MessageBoxResult.Yes)
                return;

            try
            {
                // Elimina el producte del DAO i desa els canvis a la BD
                _producteDao.EliminarProducte(producteSeleccionat.Codi);
                _producteDao.ValidarCanvis();
                Item.CODI_VALID--; // Decrementa el codi valid per mantenir la coherència
                // Torna a carregar la llista i refresca la interfície
                _totsElsProductes = _producteDao.CarregarProductes();
                tbLlistaProductes.ItemsSource = _totsElsProductes;
                tbLlistaProductes.Items.Refresh();
                actualitzarDescripcioProducte();
                actualitzarArbreDom();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"No s'ha pogut eliminar el producte: {ex.Message}",
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }


        private void AccedirInforme(object sender, RoutedEventArgs e)
        {
            Producte prod;
            if ( tbLlistaProductes.SelectedItem as Producte != null)
            {
                prod=tbLlistaProductes.SelectedItem as Producte;
                var finestra = new PopUpInforme();
                var finestraInforme = new PopUpInforme();
                finestraInforme.CarregarInforme(prod.Codi);
                finestraInforme.ShowDialog();
            }

        }
        #endregion
    }
}

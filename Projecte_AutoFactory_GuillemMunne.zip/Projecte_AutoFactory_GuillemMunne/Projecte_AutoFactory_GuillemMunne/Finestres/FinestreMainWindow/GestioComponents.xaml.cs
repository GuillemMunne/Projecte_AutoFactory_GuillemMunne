﻿using AutoFactory.DAO;
using AutoFactory.Model;
using Projecte_AutoFactory_GuillemMunne.MODEL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace ProjecteAutoFactory.Finestres.FinestreMainWindow
{
    public partial class GestioComponents : UserControl
    {
        private readonly DAOComponent _daoComponent;
        private readonly ProveidorDao _proveidorDao;
        private readonly UnitatMesuraDao _unitatMesuraDao;
        private readonly ProducteDao _producteDao;
        private readonly ProveidorComponentDao _daoProvComp;

        private List<Component> _components = new();
        private List<Proveidor> _proveidors = new();
        private List<UnitatMesura> _unitatsMesura = new();

        private ObservableCollection<ProveidorComponentItem> _componentProveidorsDisplay = new();

        public GestioComponents(
            DAOComponent daoComponent,
            ProveidorDao proveidorDao,
            ProducteDao producteDao,
            ProveidorComponentDao daoProvComp,
            UnitatMesuraDao daoUM)
        {
            InitializeComponent();
            Loaded += GestioComponents_Loaded;

            _daoComponent = daoComponent;
            _proveidorDao = proveidorDao;
            _producteDao = producteDao;
            _daoProvComp = daoProvComp;
            _unitatMesuraDao = daoUM;
        }

        private void GestioComponents_Loaded(object sender, RoutedEventArgs e)
        {
            dgProveidors.ItemsSource = _componentProveidorsDisplay;
            CarregarProveidors();
            CarregarUnitatsMesura();
            CarregarComponents();
            NetejarCamps();
        }

        private void CarregarComponents()
        {
            _components = _daoComponent.CarregarComponents();
            LlistaComponentsPrimaris.ItemsSource = _components;
        }

        private void CarregarProveidors()
        {
            _proveidors = _proveidorDao.CarregarProveidors();
            txtDependAfegirProd.ItemsSource = _proveidors;
            txtDependAfegirProd.DisplayMemberPath = "Nom";
            txtDependAfegirProd.SelectedValuePath = "Codi";
        }

        private void CarregarUnitatsMesura()
        {
            _unitatsMesura = _unitatMesuraDao.CarregarUnitatsMesura();
            cmbUnitatMesura.ItemsSource = _unitatsMesura;
            cmbUnitatMesura.DisplayMemberPath = "Nom";
            cmbUnitatMesura.SelectedValuePath = "Codi";
        }

        private void NetejarCamps()
        {
            txtNom.Text = string.Empty;
            txtCodi.Text = string.Empty;
            txtStock.Text = string.Empty;
            txtPreuMig.Text = string.Empty;
            txtDescripcio.Text = string.Empty;
            txtFoto.Text = string.Empty;
            imgFoto.Source = null;
            cmbUnitatMesura.SelectedIndex = -1;
            _componentProveidorsDisplay.Clear();
        }

        private void MostrarComponent(Component component)
        {
            if (component == null)
                return;

            txtNom.Text = component.Nom;
            txtCodi.Text = component.Codi.ToString();
            txtStock.Text = component.Stock.ToString();
            txtPreuMig.Text = component.PreuMig.ToString();
            txtDescripcio.Text = component.Descripcio;
            cmbUnitatMesura.SelectedValue = component.Unitat?.Codi;

            if (component.Foto != null && component.Foto.Length > 0)
            {
                try
                {
                    using var ms = new MemoryStream(component.Foto);
                    var bmp = new BitmapImage();
                    bmp.BeginInit();
                    bmp.CacheOption = BitmapCacheOption.OnLoad;
                    bmp.StreamSource = ms;
                    bmp.EndInit();
                    imgFoto.Source = bmp;
                }
                catch
                {
                    imgFoto.Source = null;
                }
            }
            else
            {
                imgFoto.Source = null;
            }

            _componentProveidorsDisplay.Clear();

            var dades = _daoProvComp.ObtenirProveidorsPerComponent(component.Codi);
            foreach (var d in dades)
            {
                _componentProveidorsDisplay.Add(new ProveidorComponentItem
                {
                    CodiProveidor = d.CodiProveidor,
                    NomProveidor = d.NomProveidor,
                    Preu = d.Preu
                });
            }
        }

        private void LlistaComponentsPrimaris_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LlistaComponentsPrimaris.SelectedItem is Component c)
                MostrarComponent(c);
            else
                NetejarCamps();
        }

        private void btnNouComponent_Click(object sender, RoutedEventArgs e)
        {
            LlistaComponentsPrimaris.SelectedItem = null;
            NetejarCamps();
        }

        private void btnAfegirDependencia_Click(object sender, RoutedEventArgs e)
        {
            if (txtDependAfegirProd.SelectedItem is not Proveidor prov)
                return;

            if (_componentProveidorsDisplay.Any(x => x.CodiProveidor == prov.Codi))
                return;

            _componentProveidorsDisplay.Add(new ProveidorComponentItem
            {
                CodiProveidor = prov.Codi,
                NomProveidor = prov.Nom,
                Preu = 0m
            });

            txtDependAfegirProd.SelectedIndex = -1;
        }

        private void btnEliminarDependencia_Click(object sender, RoutedEventArgs e)
        {
            if (dgProveidors.SelectedItem is ProveidorComponentItem sel)
                _componentProveidorsDisplay.Remove(sel);
        }

        private void btnModificarComponent_Click(object sender, RoutedEventArgs e)
        {
            if (LlistaComponentsPrimaris.SelectedItem is not Component selected)
            {
                MessageBox.Show(
                    "Has de seleccionar un component per modificar.",
                    "Component no seleccionat",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                return;
            }

            if (!int.TryParse(txtStock.Text, out int stock) || stock < 0)
            {
                MessageBox.Show(
                    "L'stock ha de ser un número enter igual o superior a 0.",
                    "Stock no vàlid",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                return;
            }

            if (cmbUnitatMesura.SelectedItem is not UnitatMesura um)
            {
                MessageBox.Show(
                    "Has de seleccionar una unitat de mesura.",
                    "Unitat no seleccionada",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                return;
            }


            foreach (var pci in _componentProveidorsDisplay)
            {
                if (pci.Preu <= 0)
                {
                    MessageBox.Show(
                        "Tots els proveïdors han de tenir un preu major que 0.",
                        "Preu no vàlid",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning
                    );
                    return;
                }
            }


            selected.Nom = txtNom.Text.Trim();
            selected.Descripcio = txtDescripcio.Text.Trim();
            selected.Stock = stock;
            selected.Unitat = um;

            if (!string.IsNullOrWhiteSpace(txtFoto.Text) && File.Exists(txtFoto.Text))
            {
                try { selected.Foto = File.ReadAllBytes(txtFoto.Text); } catch { }
            }

            selected.BuidaProveidors();
            foreach (var pci in _componentProveidorsDisplay)
                selected.afegirProveidor(pci);

            _daoComponent.ModificarComponent(selected);
            _producteDao.ValidarCanvis();

            txtPreuMig.Text = selected.PreuMig.ToString();
            LlistaComponentsPrimaris.Items.Refresh();
            MostrarComponent(selected);
        }

        private void btnAfegirComponent_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(txtStock.Text, out int stock) || stock < 0)
                return;

            if (cmbUnitatMesura.SelectedItem is not UnitatMesura um)
                return;

            var nou = new Component
            {
                Codi = Item.CODI_VALID++,
                Nom = txtNom.Text.Trim(),
                Descripcio = txtDescripcio.Text.Trim(),
                Stock = stock,
                Unitat = um
            };

            if (!string.IsNullOrWhiteSpace(txtFoto.Text) && File.Exists(txtFoto.Text))
            {
                try { nou.Foto = File.ReadAllBytes(txtFoto.Text); } catch { }
            }

            foreach (var pci in _componentProveidorsDisplay)
                nou.afegirProveidor(pci);

            _daoComponent.AfegirComponent(nou);
            _producteDao.ValidarCanvis();

            CarregarComponents();
            NetejarCamps();
        }

        private void btnEliminarComponent_Click(object sender, RoutedEventArgs e)
        {
            if (LlistaComponentsPrimaris.SelectedItem is not Component component)
                return;

            _daoComponent.EliminarComponent(component.Codi);

            foreach (var p in _producteDao.ObtenirTots())
                p.Conte.Remove(component);

            _producteDao.ValidarCanvis();

            CarregarComponents();
            NetejarCamps();
        }

        private void tbCercaComponent_TextChanged(object sender, TextChangedEventArgs e)
        {
            string text = tbCercaComponent.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(text))
                LlistaComponentsPrimaris.ItemsSource = _components;
            else
                LlistaComponentsPrimaris.ItemsSource = _components
                    .Where(c => c.Nom != null && c.Nom.ToLower().Contains(text))
                    .ToList();
        }

        private void txtDependAfegirProd_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }
    }
}

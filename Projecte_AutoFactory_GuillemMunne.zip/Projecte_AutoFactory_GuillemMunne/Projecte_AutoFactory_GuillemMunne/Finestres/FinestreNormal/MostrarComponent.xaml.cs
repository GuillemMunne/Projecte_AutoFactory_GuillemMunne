﻿using System.Windows;
using System.Windows.Controls;

namespace AutoFactoryProjecte.Finestres.FinestreNormal
{
    /// <summary>
    /// Lógica de interacción para MostrarProducte.xaml
    /// </summary>
    public partial class MostrarComponent : Window
    {
        public MostrarComponent()
        {
            InitializeComponent();
        }

        private void lstConte_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}

﻿using AutoFactory.Model;
using System;
using System.Collections.Generic;
using System.Windows;

namespace ProjecteAutoFactory.Finestres.FinestreNormal
{
    /// <summary>
    /// Finestra per seleccionar un ítem i una quantitat a afegir com a dependència.
    /// </summary>
    public partial class AfegirDependencia : Window
    {
        private readonly List<Item> _itemsDisponibles;

        /// <summary>
        /// ItemQuantitat seleccionat. És null si l'usuari cancel·la.
        /// </summary>
        public ItemQuantitat? Resultat { get; private set; }

        public AfegirDependencia(List<Item> itemsDisponibles)
        {
            InitializeComponent();
            _itemsDisponibles = itemsDisponibles ?? throw new ArgumentNullException(nameof(itemsDisponibles));
            cmbItems.ItemsSource = _itemsDisponibles;
            if (_itemsDisponibles.Count > 0)
                cmbItems.SelectedIndex = 0;
        }

        private void Acceptar_Click(object sender, RoutedEventArgs e)
        {
            if (cmbItems.SelectedItem is not Item item)
            {
                MessageBox.Show("Selecciona un item.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(txtQuantitat.Text, out int quantitat) || quantitat <= 0)
            {
                MessageBox.Show("La quantitat ha de ser un nombre enter positiu.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var itemQuantitat = new ItemQuantitat(item) { Quantitat = quantitat };

            Resultat = itemQuantitat;
            DialogResult = true;
            Close();
        }

        private void Cancelar_Click(object sender, RoutedEventArgs e)
        {
            Resultat = null;
            DialogResult = false;
            Close();
        }
    }
}

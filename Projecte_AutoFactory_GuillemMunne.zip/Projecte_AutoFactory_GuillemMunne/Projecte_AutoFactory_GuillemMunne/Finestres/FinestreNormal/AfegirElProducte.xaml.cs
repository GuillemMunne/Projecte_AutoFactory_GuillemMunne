﻿using AutoFactory.DAO;
using AutoFactory.IDAO;
using AutoFactory.Model;
using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace ProjecteAutoFactory.Finestres.FinestreNormal
{
    public partial class AfegirElProducte : Window
    {
        private readonly ProducteDao _producteDao;
        private readonly DAOComponent _componentDao;
        private ObservableCollection<ItemQuantitat> _itemsDisponibles = new();
        public Producte? NouProducte { get; private set; }
        private readonly Producte? _producteOriginal;

        public AfegirElProducte(ProducteDao producteDao, DAOComponent componentDao)
        {
            InitializeComponent();
            _producteDao = producteDao;
            _componentDao = componentDao;
            Loaded += AfegirElProducte_Loaded;
        }

        public AfegirElProducte(ProducteDao producteDao, DAOComponent componentDao, Producte producteOriginal)
            : this(producteDao, componentDao)
        {
            _producteOriginal = producteOriginal;
        }

        private void AfegirElProducte_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var p in _producteDao.ObtenirTots())
            {
                _itemsDisponibles.Add(new ItemQuantitat(p));
            }

            foreach (var c in _componentDao.ObtenirTots())
            {
                _itemsDisponibles.Add(new ItemQuantitat(c));
            }

            lstConte.ItemsSource = _itemsDisponibles;

            if (_producteOriginal != null)
            {
                txtCodi.Text = _producteOriginal.Codi.ToString();
                txtNom.Text = _producteOriginal.Nom;
                txtDescripcio.Text = _producteOriginal.Descripcio;
                txtStock.Text = _producteOriginal.Stock.ToString();
                txtCodi.IsEnabled = false;

                foreach (var iq in _itemsDisponibles)
                {
                    if (_producteOriginal.Conte.TryGetValue(iq.Item, out int quant))
                    {
                        iq.Quantitat = quant;
                    }
                }
            }
        }

        private void Acceptar_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNom.Text) || string.IsNullOrWhiteSpace(txtStock.Text))
            {
                MessageBox.Show("Omple el camp Nom i Stock.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(txtStock.Text, out int stock) || stock < 0)
            {
                MessageBox.Show("L'stock ha de ser un nombre enter positiu.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Producte producte;
            if (_producteOriginal != null)
            {
                producte = _producteOriginal;
            }
            else
            {
                producte = new Producte(Item.CODI_VALID, txtNom.Text.Trim(), txtDescripcio.Text.Trim(), stock, Array.Empty<byte>());
            }

            producte.Nom = txtNom.Text.Trim();
            producte.Descripcio = txtDescripcio.Text.Trim();
            producte.Stock = stock;
            producte.Conte.Clear();
            foreach (var iq in _itemsDisponibles.Where(i => i.Quantitat > 0))
            {
                producte.Conte[iq.Item] = iq.Quantitat;
            }

            NouProducte = producte;
            DialogResult = true;
            Close();
        }

        private void Cancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void NomésNumeros(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void inserirImatge(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                Filter = "Imatges|*.jpg;*.jpeg;*.png;*.bmp",
                Title = "Selecciona una imatge"
            };

            if (dlg.ShowDialog() == true)
            {
                imgFoto.Source = new BitmapImage(new Uri(dlg.FileName));
            }
        }
    }
}

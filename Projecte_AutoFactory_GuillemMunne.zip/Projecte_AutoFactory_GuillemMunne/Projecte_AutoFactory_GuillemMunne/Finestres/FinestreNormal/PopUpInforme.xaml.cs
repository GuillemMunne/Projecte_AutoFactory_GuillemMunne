﻿using System;
using System.Collections.Generic;
using System.Windows;

using Microsoft.Web.WebView2.Core;

namespace Projecte_AutoFactory_GuillemMunne.Finestres.FinestreNormal
{
    /// <summary>
    /// Interaction logic for PopUpInforme.xaml
    /// </summary>
    public partial class PopUpInforme : Window
    {

        public PopUpInforme()
        {
            InitializeComponent();
            InitializeAsync();
        }

        private async void InitializeAsync()
        {
            await webViewInforme.EnsureCoreWebView2Async(null);
        }

        public void CarregarInforme(int producteCodi)
        {
            
            string urlInforme = $"http://localhost:8080/jasperserver/flow.html?_flowId=viewReportFlow&_flowId=viewReportFlow&ParentFolderUri=%2FAutofactory&reportUnit=%2FAutofactory%2FAutofactoryReport&standAlone=true" +
                    $"?CodiProducte={producteCodi}&j_username=jasperadmin&j_password=jasperadmin";


            webViewInforme.Source = new Uri(urlInforme);
        }

    }
}

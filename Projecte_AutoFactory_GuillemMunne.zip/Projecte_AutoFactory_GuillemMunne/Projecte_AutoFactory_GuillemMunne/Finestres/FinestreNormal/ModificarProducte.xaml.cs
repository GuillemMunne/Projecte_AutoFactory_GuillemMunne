﻿using AutoFactory.DAO;
using AutoFactory.Model;
using Microsoft.Win32;
using ProjecteAutoFactory.Finestres.FinestreNormal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace ProjecteAutoFactory.Finestres.FinestreNormal
{
    /// <summary>
    /// Finestra per modificar un producte existent i gestionar-ne els ítems relacionats.
    /// </summary>
    public partial class ModificarProducte : Window
    {
        private readonly ProducteDao _producteDao;
        private readonly DAOComponent _componentDao;

        public Producte producteSeleccionat { get; private set; }

        // Llista d'ítems (components o productes) seleccionats amb la seva quantitat
        private ObservableCollection<ItemQuantitat> _itemsSeleccionats = new();

        // Tots els ítems disponibles per afegir
        private List<Item> _totsElsItems = new();

        public ModificarProducte(Producte producteSeleccionat, ProducteDao producteDao, DAOComponent componentDao)
        {
            InitializeComponent();

            this.producteSeleccionat = producteSeleccionat ?? throw new ArgumentNullException(nameof(producteSeleccionat));
            _producteDao = producteDao ?? throw new ArgumentNullException(nameof(producteDao));
            _componentDao = componentDao ?? throw new ArgumentNullException(nameof(componentDao));

            CargarDadesProducte();
        }

        /// <summary>
        /// Carrega els camps bàsics i inicialitza les llistes d'ítems seleccionats i disponibles.
        /// </summary>
        private void CargarDadesProducte()
        {
            // Camps bàsics
            txtCodi.Text = producteSeleccionat.Codi.ToString();
            txtNom.Text = producteSeleccionat.Nom;
            txtDescripcio.Text = producteSeleccionat.Descripcio;
            txtStock.Text = producteSeleccionat.Stock.ToString();

            // Mostrar foto si ja existeix (producteSeleccionat.Foto és byte[])
            if (producteSeleccionat.Foto != null && producteSeleccionat.Foto.Length > 0)
            {
                try
                {
                    using var ms = new MemoryStream(producteSeleccionat.Foto);
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.StreamSource = ms;
                    bitmap.EndInit();
                    imgFoto.Source = bitmap;
                }
                catch
                {
                    imgFoto.Source = null;
                }
            }

            // Llista d'ítems disponibles (tots els productes i components menys el producte actual)
            _totsElsItems.Clear();
            foreach (var p in _producteDao.ObtenirTots())
            {
                if (p.Codi != producteSeleccionat.Codi)
                    _totsElsItems.Add(p);
            }
            foreach (var c in _componentDao.ObtenirTots())
                _totsElsItems.Add(c);

            // Llista d'ítems que ja formen part del producte
            _itemsSeleccionats = new ObservableCollection<ItemQuantitat>();
            foreach (var kv in producteSeleccionat.Conte)
            {
                var iq = new ItemQuantitat(kv.Key) { Quantitat = kv.Value };
                _itemsSeleccionats.Add(iq);
            }
            lstDependModfiProd.ItemsSource = _itemsSeleccionats;
        }

        /// <summary>
        /// Es força que només s'introdueixin números en un TextBox.
        /// </summary>
        private void NomésNumeros(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        /// <summary>
        /// Afegeix una nova dependència a la llista. Obre una finestra per triar item i quantitat.
        /// </summary>
        private void btnAfegirDependencia_Click(object sender, RoutedEventArgs e)
        {
            // Llista d'ítems que encara no s'han afegit
            var disponibles = _totsElsItems.Where(i => !_itemsSeleccionats.Any(sel => sel.Item.Equals(i))).ToList();
            if (disponibles.Count == 0)
            {
                MessageBox.Show("No hi ha més ítems disponibles per afegir.", "Informació", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var popUp = new AfegirDependencia(disponibles) { Owner = this };

            if (popUp.ShowDialog() == true && popUp.Resultat != null)
            {
                _itemsSeleccionats.Add(popUp.Resultat);
            }
        }

        /// <summary>
        /// Elimina el ítem seleccionat de la llista de dependències.
        /// </summary>
        private void btnEliminarDependencia_Click(object sender, RoutedEventArgs e)
        {
            if (lstDependModfiProd.SelectedItem is ItemQuantitat selected)
            {
                _itemsSeleccionats.Remove(selected);
            }
        }

        /// <summary>
        /// Permet seleccionar una imatge i mostrar-la al formulari. Desa la ruta en txtFoto.
        /// </summary>
        private void inserirImatge(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                Filter = "Imatges|*.jpg;*.jpeg;*.png;*.bmp;*.gif",
                Title = "Selecciona una imatge"
            };

            if (dlg.ShowDialog() == true)
            {
                string ruta = dlg.FileName;
                imgFoto.Source = new BitmapImage(new Uri(ruta, UriKind.Absolute));
                txtFoto.Text = ruta;
            }
        }

        /// <summary>
        /// Valida els camps i desa els canvis: actualitza l'objecte en memòria i persisteix a la BD.
        /// </summary>
        private void Acceptar_Click(object sender, RoutedEventArgs e)
        {
            // Validar camps obligatoris
            if (string.IsNullOrWhiteSpace(txtNom.Text) || string.IsNullOrWhiteSpace(txtStock.Text))
            {
                MessageBox.Show("Si us plau, ompleu els camps Nom i Stock.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(txtStock.Text, out int stock) || stock < 0)
            {
                MessageBox.Show("L'stock ha de ser un nombre enter positiu.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (txtNom.Text.Length > 100)
            {
                MessageBox.Show("El nom no pot superar 100 caràcters.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (txtDescripcio.Text.Length > 400)
            {
                MessageBox.Show("La descripció no pot superar 400 caràcters.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Actualitzar camps bàsics
            producteSeleccionat.Nom = txtNom.Text.Trim();
            producteSeleccionat.Descripcio = txtDescripcio.Text.Trim();
            producteSeleccionat.Stock = stock;

            // Actualitzar foto si s'ha triat una ruta
            if (!string.IsNullOrWhiteSpace(txtFoto.Text) && File.Exists(txtFoto.Text))
            {
                try
                {
                    producteSeleccionat.Foto = File.ReadAllBytes(txtFoto.Text);
                }
                catch
                {
                    // Si hi ha error es manté la foto actual
                }
            }

            // Actualitzar dependències
            producteSeleccionat.Conte.Clear();
            foreach (var iq in _itemsSeleccionats)
            {
                if (iq.Quantitat > 0)
                    producteSeleccionat.Conte[iq.Item] = iq.Quantitat;
            }

            try
            {
                // Modificar i validar al DAO
                _producteDao.ModificarProducte(producteSeleccionat);
                _producteDao.ValidarCanvis();

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"S'ha produït un error en desar el producte: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Cancel·la l'edició i tanca la finestra.
        /// </summary>
        private void Cancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}

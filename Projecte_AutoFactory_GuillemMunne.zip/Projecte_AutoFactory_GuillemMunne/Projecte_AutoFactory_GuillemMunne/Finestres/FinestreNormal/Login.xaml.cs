﻿using Oracle.ManagedDataAccess.Client;
using System.Windows;

namespace ProjecteAutoFactory.Finestres.FinestreMainWindow
{
    public partial class Login : Window
    {
        private string _connectionString =
            "User Id=alumne;" +
            "Password=alumne;" +
            "Data Source=(DESCRIPTION=" +
            "(ADDRESS=(PROTOCOL=TCP)(HOST=127.0.0.1)(PORT=1521))" +
            "(CONNECT_DATA=(SERVICE_NAME=XEPDB1))" +
            ");";

        public Login()
        {
            InitializeComponent();
        }

        private void LoginButton_click(object sender, RoutedEventArgs e)
        {
            string usuari = UsernameTextBox.Text.Trim();
            string contrasenya = PasswordBox.Password.Trim();

            if (string.IsNullOrEmpty(usuari) || string.IsNullOrEmpty(contrasenya))
            {
                MessageBox.Show(
                    "Introdueix usuari i contrasenya.",
                    "Dades incompletes",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                return;
            }

            bool loginCorrecte = false;

            using (var conn = new OracleConnection(_connectionString))
            {
                conn.Open();

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        @"SELECT COUNT(*)
                          FROM USUARIS
                          WHERE USUARI = :usuari
                            AND CONTRASENYA = :contrasenya";

                    cmd.BindByName = true;

                    cmd.Parameters.Add(new OracleParameter("usuari", usuari));
                    cmd.Parameters.Add(new OracleParameter("contrasenya", contrasenya));

                    int count = System.Convert.ToInt32(cmd.ExecuteScalar());
                    loginCorrecte = count == 1;
                }
            }

            if (loginCorrecte)
            {
                
                var finestraMain = new MainWindow();
                finestraMain.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show(
                    "Usuari o contrasenya incorrectes.",
                    "Error de login",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }
    }
}

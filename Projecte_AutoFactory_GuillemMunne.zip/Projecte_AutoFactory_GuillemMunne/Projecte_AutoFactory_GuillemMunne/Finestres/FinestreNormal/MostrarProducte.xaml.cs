﻿using System.Windows;

namespace AutoFactoryProjecte.Finestres.FinestreNormal
{
    /// <summary>
    /// Lógica de interacción para MostrarProducte.xaml
    /// </summary>
    public partial class MostrarProducte : Window
    {
        public MostrarProducte()
        {
            InitializeComponent();
        }
    }
}

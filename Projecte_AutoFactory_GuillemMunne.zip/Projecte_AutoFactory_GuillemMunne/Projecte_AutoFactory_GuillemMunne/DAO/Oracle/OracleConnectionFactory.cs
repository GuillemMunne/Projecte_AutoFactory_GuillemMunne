using Oracle.ManagedDataAccess.Client;
using System;
using System.Windows;

namespace AutoFactory.DAO.Oracle
{
    public sealed class OracleConnectionFactory
    {
        private readonly string _connectionString;

        public OracleConnectionFactory(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new ArgumentException("La cadena de connexió no pot estar buida.", nameof(connectionString));
            }

            _connectionString = connectionString;
        }

        public OracleConnection CreateOpenConnection()
        {
            try
            {
                var conn = new OracleConnection(_connectionString);
                conn.Open();

                return conn;
            }
            catch (OracleException ex)
            {
                MessageBox.Show(
                    ex.Message + "\n\n" + ex.Number,
                    "Error Oracle",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                throw;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoFactory.DAO.Oracle;
using AutoFactory.IDAO;
using AutoFactory.Model;
using Oracle.ManagedDataAccess.Client;
using Projecte_AutoFactory_GuillemMunne.MODEL;
using OracleDatabase = AutoFactory.DAO.Oracle.OracleDatabase;

namespace AutoFactory.DAO
{


    public sealed class ProducteDao : IDAOProducte
    {

        // ===============================
        // SQL
        // ===============================

        private const string SelectAllSql = @"
    SELECT
    it_codi   AS CODI,
    it_nom    AS NOM,
    it_desc   AS DESCRIPCIO,
    it_stock  AS STOCK,
    it_foto   AS FOTO
FROM ITEM
WHERE IT_TIPUS = 'P'
ORDER BY it_codi

";

        private const string SelectSubitemsSql = @"
    SELECT
    i.it_codi,
    i.it_nom,
    i.it_desc,
    i.it_stock,
    i.it_foto,
    i.it_tipus,
    pi.quantitat
FROM PROD_ITEM pi
JOIN ITEM i ON i.it_codi = pi.pi_it_codi
WHERE pi.pi_pr_codi = :codiProducte


";

        private const string InsertItemProducteSql = @"
INSERT INTO Item
    (it_codi, it_tipus, it_nom, it_desc, it_stock, it_foto)
VALUES
    (:codi, 'P', :nom, :descripcio, :stock, :foto)
";


        private const string InsertProducteSql =
            @"INSERT INTO PRODUCTE (PR_CODI) VALUES (:codi)";

        private const string InsertProdItemSql = @"
    INSERT INTO PROD_ITEM (PI_PR_CODI, PI_IT_CODI, QUANTITAT)
    VALUES (:pr_codi, :it_codi, :quantitat)
";

        private const string DeleteProdItemSql = @"DELETE FROM PROD_ITEM";
        private const string DeleteProducteSql = @"DELETE FROM PRODUCTE";


        const string insertProveidorSql = @"
INSERT INTO PROVEIDOR
(
    pv_codi,
    pv_cif,
    pv_rao_social,
    pv_persona_contacte,
    pv_telef_contacte,
    pv_lin_adre_fac,
    pv_mu_pr_codi
)
VALUES
(
    :codi,
    :cif,
    :rao_social,
    :persona_contacte,
    :telf_contacte,
    :linia_adreca,
    :municipi
)
";


        // ===============================
        // CAMPOS
        // ===============================

        private readonly OracleDatabase _database;
        private List<Producte> _productes = new();
        private readonly OracleConnectionFactory _connectionFactory;
        private Dictionary<int, Producte> _productesPerCodi = new();
        private readonly IDAOComponent _componentDao;
        private ProveidorDao _ProveidorDao;
        private List<Proveidor> proveidors = new List<Proveidor>();


        // ===============================
        // CONSTRUCTOR
        // ===============================

        public ProducteDao(
    OracleDatabase database,
    OracleConnectionFactory connectionFactory,
    IDAOComponent componentDao,
    ProveidorDao proveidorDao)
        {
            _database = database;
            _connectionFactory = connectionFactory;
            _componentDao = componentDao;
            _ProveidorDao = proveidorDao;
            proveidors = _ProveidorDao.ObtenirTots();
            CarregarProductes();
        }



        // ===============================
        // CÀRREGA
        // ===============================

        public List<Producte> CarregarProductes()
        {
            _productes = _database.ExecuteQuery(SelectAllSql, MapProducte).ToList();

            _productesPerCodi = _productes.ToDictionary(p => p.Codi);
            
            foreach (var p in _productes)
                CarregarSubitemsRecursiu(p);

            return _productes;
        }


        private void CarregarSubitemsRecursiu(Producte producte)
        {
            producte.Conte.Clear();

            var parameters = new[]
            {
        new OracleParameter("codiProducte", producte.Codi)
    };

            var rows = _database.ExecuteQuery(
                SelectSubitemsSql,
                MapSubitem,
                parameters);

            foreach (var (item, quantitat) in rows)
            {
                producte.Conte[item] = quantitat;

                // 🔑 SI EL FILL ÉS UN PRODUCTE → BAIXEM
                if (item is Producte subproducte)
                {
                    CarregarSubitemsRecursiu(subproducte);
                }
            }
        }


        // ===============================
        // CRUD EN MEMÒRIA
        // ===============================

        public IReadOnlyList<Producte> ObtenirTots() => _productes;

        public Producte? ObtenirProducte(int codi)
            => _productes.FirstOrDefault(p => p.Codi == codi);

        public void AfegirProducte(Producte producte)
        {
            if (producte == null) throw new ArgumentNullException(nameof(producte));
            _productes.Add(producte);
        }

        public void EliminarProducte(int codi)
        {
            var p = ObtenirProducte(codi);
            if (p != null) _productes.Remove(p);
        }

        public void ModificarProducte(Producte producte)
        {
            if (producte == null)
                throw new ArgumentNullException(nameof(producte));

            int index = _productes.FindIndex(p => p.Codi == producte.Codi);
            if (index < 0)
                return;

            _productes[index] = producte;
        }





        // ===============================
        // PERSISTÈNCIA
        // ===============================

        private static object Db(object? value)
        {
            return value ?? DBNull.Value;
        }



        public void ValidarCanvis()
        {
            using var conn = _connectionFactory.CreateOpenConnection();
            using var tran = conn.BeginTransaction();

            try
            {
                // =====================================================
                // 1️⃣ DELETE – ordre correcte segons FK
                // =====================================================
                // =====================================================
                // 1️⃣ DELETE – ordre correcte segons FK
                // =====================================================
                _database.ExecuteNonQuery(conn, "DELETE FROM PROD_ITEM", Array.Empty<OracleParameter>(), tran);
                _database.ExecuteNonQuery(conn, "DELETE FROM PROV_COMP", Array.Empty<OracleParameter>(), tran);
                _database.ExecuteNonQuery(conn, "DELETE FROM PRODUCTE", Array.Empty<OracleParameter>(), tran);
                _database.ExecuteNonQuery(conn, "DELETE FROM COMPONENT", Array.Empty<OracleParameter>(), tran);
                _database.ExecuteNonQuery(conn, "DELETE FROM PROVEIDOR", Array.Empty<OracleParameter>(), tran);
                _database.ExecuteNonQuery(conn, "DELETE FROM ITEM", Array.Empty<OracleParameter>(), tran);


                // =====================================================
                // 2️⃣ RECOLLIM TOTS ELS ITEMS (Productes + Components)
                // =====================================================
                var items = new HashSet<Item>();

                foreach (var p in _productes)
                    RecollirItemsRecursiu(p, items);

                var componentsBons = _componentDao.ObtenirTots()
    .ToDictionary(c => c.Codi);

                foreach (var p in _productes)
                {
                    var claus = p.Conte.Keys.ToList();

                    foreach (var item in claus)
                    {
                        if (item is Component comp &&
                            componentsBons.TryGetValue(comp.Codi, out var compBo))
                        {
                            int quantitat = p.Conte[item];
                            p.Conte.Remove(item);
                            p.Conte[compBo] = quantitat;
                        }
                    }
                }

                items.Clear();

                foreach (var p in _productes)
                    RecollirItemsRecursiu(p, items);

                foreach (var c in componentsBons.Values)
                {
                    if (!items.Contains(c))
                        items.Add(c);
                }


                // =====================================================
                // 3️⃣ INSERT ITEM
                // =====================================================
                const string insertItemSql = @"
INSERT INTO Item
(it_codi, it_tipus, it_nom, it_desc, it_stock, it_foto)
VALUES (:codi, :tipus, :nom, :descripcio, :stock, :foto)
";

                foreach (var item in items)
                {
                    if (string.IsNullOrWhiteSpace(item.Nom))
                        throw new InvalidOperationException(
                            $"Item {item.Codi} sense nom."
                        );

                    _database.ExecuteNonQuery(
                        conn,
                        insertItemSql,
                        new[]
                        {
                    new OracleParameter("codi", item.Codi),
                    new OracleParameter("tipus", item is Producte ? "P" : "C"),
                    new OracleParameter("nom", item.Nom),
                    new OracleParameter("descripcio", item.Descripcio ?? ""),
                    new OracleParameter("stock", item.Stock),
                    new OracleParameter("foto", item.Foto ?? (object)DBNull.Value)
                        },
                        tran
                    );
                }

                // =====================================================
                // 4️⃣ INSERT PRODUCTE (només el codi)
                // =====================================================
                const string insertProducteSql =
                    @"INSERT INTO Producte (pr_codi) VALUES (:codi)";

                foreach (var p in _productes)
                {
                    _database.ExecuteNonQuery(
                        conn,
                        insertProducteSql,
                        new[] { new OracleParameter("codi", p.Codi) },
                        tran
                    );
                }

                // =====================================================
                // 5️⃣ INSERT COMPONENT
                // =====================================================
                const string insertComponentSql = @"
INSERT INTO Component
(cm_codi, cm_um_codi, cm_codi_fabricant, cm_preu_mig)
VALUES (:codi, :um, :fabricant, :preu)
";

                foreach (var component in items.OfType<Component>())
                {
                    if (component.Unitat == null)
                        throw new InvalidOperationException(
                            $"El component {component.Codi} no té Unitat de Mesura assignada."
                        );

                    _database.ExecuteNonQuery(
                        conn,
                        insertComponentSql,
                        new[]
                        {
                    new OracleParameter("codi", component.Codi),
                    new OracleParameter("um", component.Unitat.Codi),
                    new OracleParameter("fabricant", component.CodiFabricant),
                    new OracleParameter("preu", component.PreuMig)
                        },
                        tran
                    );
                }

                // =====================================================
                // 6️⃣ INSERT PROD_ITEM (relacions)
                // =====================================================
                const string insertProdItemSql = @"
INSERT INTO Prod_Item
(pi_pr_codi, pi_it_codi, quantitat)
VALUES (:pr_codi, :it_codi, :quantitat)
";

                foreach (var p in _productes)
                {
                    foreach (var kv in p.Conte)
                    {
                        _database.ExecuteNonQuery(
                            conn,
                            insertProdItemSql,
                            new[]
                            {
                        new OracleParameter("pr_codi", p.Codi),
                        new OracleParameter("it_codi", kv.Key.Codi),
                        new OracleParameter("quantitat", kv.Value)
                            },
                            tran
                        );
                    }
                }


                // =====================================================
                // 6️⃣ INSERT PROVEÏDOR
                // =====================================================


                foreach (var prov in proveidors)
                {

                    _database.ExecuteNonQuery(
     conn,
     insertProveidorSql,
     new[]
     {
        new OracleParameter("codi", prov.Codi),
        new OracleParameter("cif", Db(prov.GetCif())),
        new OracleParameter("rao_social", Db(prov.GetRS())),
        new OracleParameter("persona_contacte", Db(prov.GetPersonaContacte())),
        new OracleParameter("telf_contacte", Db(prov.GetTelefonContacte())),
        new OracleParameter("linia_adreca", Db(prov.GetLAF())),
        new OracleParameter(
            "municipi",
            prov.GetMunicipi() != null
                ? prov.GetMunicipi().CodiMunicipi
                : 1
        )
     },
     tran
 );



                }




                // =====================================================
                // 7️⃣ INSERT PROV_COMP (relacions Component–Proveïdor)
                // =====================================================
                const string insertProvCompSql = @"
INSERT INTO Prov_Comp (pc_cm_codi, pc_pv_codi, pc_preu)
VALUES (:codiComp, :codiProv, :preu)
";

                

                foreach (Component component in items.OfType<Component>())
                {
                    foreach (ProveidorComponentItem kvp in component.ObtenirProveidors())
                    {
                        var prov = kvp.CodiProveidor;
                        var preu = kvp.Preu;

                        _database.ExecuteNonQuery(
                            conn,
                            insertProvCompSql,
                            new[]
                            {
                new OracleParameter("codiComp", component.Codi),
                new OracleParameter("codiProv", prov),
                new OracleParameter("preu", preu)
                            },
                            tran
                        );
                    }
                }






                // =====================================================
                //80 COMMIT
                // =====================================================
                tran.Commit();
            }
            catch
            {
                tran.Rollback();
                throw;
            }
        }




        private void RecollirItemsRecursiu(Producte producte, HashSet<Item> items)
        {
            if (!items.Add(producte))
                return;

            foreach (var kv in producte.Conte)
            {
                var item = kv.Key;

                if (items.Add(item) && item is Producte subproducte)
                {
                    RecollirItemsRecursiu(subproducte, items);
                }
            }
        }















        public void DesferCanvis()
        {
            CarregarProductes();
        }

        public void TancarCapa()
        {
            _productes.Clear();
            
        }



        // ===============================
        // MAPPERS
        // ===============================

        private static Producte MapProducte(OracleDataReader r)
        {
            int codi = r.GetInt32(r.GetOrdinal("CODI"));

            string nom = r.IsDBNull(r.GetOrdinal("NOM"))
                ? string.Empty
                : r.GetString(r.GetOrdinal("NOM"));

            string desc = r.IsDBNull(r.GetOrdinal("DESCRIPCIO"))
                ? string.Empty
                : r.GetString(r.GetOrdinal("DESCRIPCIO"));

            int stock = r.IsDBNull(r.GetOrdinal("STOCK"))
                ? 0
                : r.GetInt32(r.GetOrdinal("STOCK"));

            byte[] foto = GetNullableBytes(r, "FOTO") ?? Array.Empty<byte>();

            return new Producte(codi, nom, desc, stock, foto);
        }


        private (Item, int) MapSubitem(OracleDataReader r)
        {
            int codi = r.GetInt32(r.GetOrdinal("IT_CODI"));
            string tipus = r.GetString(r.GetOrdinal("IT_TIPUS"));
            int quantitat = r.GetInt32(r.GetOrdinal("QUANTITAT"));

            Item item;

            if (tipus == "P")
            {
                if (!_productesPerCodi.TryGetValue(codi, out var producte))
                    throw new InvalidOperationException(
                        $"Subproducte {codi} no carregat."
                    );

                item = producte;
            }
            else
            {
                // 🔑 IMPORTANT: Component COMPLET des del DAOComponent
                var component = _componentDao.ObtenirComponent(codi);

                if (component == null)
                    throw new InvalidOperationException(
                        $"Component {codi} no existeix a la BD."
                    );

                item = component;
            }

            return (item, quantitat);
        }




        private static byte[]? GetNullableBytes(OracleDataReader r, string col)
        {
            int ord = r.GetOrdinal(col);
            return r.IsDBNull(ord) ? null : (byte[])r.GetValue(ord);
        }
    }
}

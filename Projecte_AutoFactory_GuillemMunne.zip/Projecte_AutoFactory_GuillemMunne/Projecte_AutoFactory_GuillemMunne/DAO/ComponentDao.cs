﻿
using AutoFactory.DAO.Oracle;
using AutoFactory.IDAO;
using AutoFactory.Model;
using Oracle.ManagedDataAccess.Client;
using Projecte_AutoFactory_GuillemMunne.MODEL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OracleDatabase = AutoFactory.DAO.Oracle.OracleDatabase;

namespace AutoFactory.DAO
{
    public sealed class DAOComponent : IDAOComponent
    {
        private readonly OracleDatabase _database;
        private readonly OracleConnectionFactory _connectionFactory;
        private List<Component> _components = new();
        private ProveidorDao _proveidorDao;

        // ===============================
        // SQL
        // ===============================

        private const string SelectAllSql = @"
            SELECT
                i.it_codi,
                i.it_nom,
                i.it_desc,
                i.it_stock,
                i.it_foto,
                c.cm_codi_fabricant,
                c.cm_preu_mig,
                c.cm_um_codi,
                um.um_nom AS UM_NOM
            FROM Component c
            JOIN Item i ON i.it_codi = c.cm_codi
            JOIN UnitatMesura um ON um.um_codi = c.cm_um_codi
        ";

        private const string InsertItemSql = @"
            INSERT INTO Item
                (it_codi, it_tipus, it_nom, it_desc, it_stock, it_foto)
            VALUES
                (:codi, 'C', :nom, :descripcio, :stock, :foto)
        ";

        private const string InsertComponentSql = @"
            INSERT INTO Component
                (cm_codi, cm_um_codi, cm_codi_fabricant, cm_preu_mig)
            VALUES
                (:codi, :um, :fabricant, :preu)
        ";

        private const string SelectProveidorsComponentSql = @"
    SELECT
        pc.pc_cm_codi,
        pc.pc_pv_codi,
        pc.pc_preu
    FROM Prov_Comp pc
    WHERE pc.pc_cm_codi = :codiComponent
";



        // ===============================
        // CONSTRUCTOR
        // ===============================

        public DAOComponent(
             OracleDatabase database,
             OracleConnectionFactory connectionFactory,
             ProveidorDao proveidorDao)
        {
            _database = database ?? throw new ArgumentNullException(nameof(database));
            _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
            _proveidorDao = proveidorDao;
            CarregarComponents();
            
        }


        // ===============================
        // CÀRREGA
        // ===============================

        public List<Component> CarregarComponents()
        {
            _components = _database.ExecuteQuery(SelectAllSql, MapComponent).ToList();
            int idProv;
            foreach (var c in _components)
            {
                ObtenirProveidorsComponent(c.Codi).ForEach(pc =>
                {
                Proveidor prov = _proveidorDao.ObtenirProveidor(pc.CodiProveidor);

                    c.afegirProveidor(new ProveidorComponentItem
                    {
                        CodiProveidor = pc.CodiProveidor,
                        Preu = pc.Preu,
                        NomProveidor = prov.GetRS()
                    });
                    
                    
                });
            }
            return _components;
        }

        public IReadOnlyList<Component> ObtenirTots() => _components;

        public Component? ObtenirComponent(int codi)
            => _components.FirstOrDefault(c => c.Codi == codi);


        public List<int> ObtenirCodiComponentPerProveidor(int codiProv)
        {
            var parameters = new[]
            {
                new OracleParameter("codi", OracleDbType.Int32)
                {
                    Value = codiProv
                }
            };

            return _database.ExecuteQuery(
                @"SELECT pc_cm_codi
          FROM Prov_Comp
          WHERE pc_pv_codi = :codi",
                r => r.GetInt32(0),
                parameters
            ).ToList();
        }


        // ===============================
        // CRUD MEMÒRIA
        // ===============================

        public void AfegirComponent(Component component)
        {
            if (component == null)
                throw new ArgumentNullException(nameof(component));

            if (component.Unitat == null)
                throw new InvalidOperationException(
                    $"El component {component.Codi} no té Unitat de Mesura."
                );

            _components.Add(component);
        }

        public void ModificarComponent(Component component)
        {
            var existent = ObtenirComponent(component.Codi);
            if (existent == null) return;

            existent.Nom = component.Nom;
            existent.Descripcio = component.Descripcio;
            existent.Stock = component.Stock;
            existent.Foto = component.Foto;
            existent.CodiFabricant = component.CodiFabricant;
            existent.PreuMig = component.PreuMig;
            existent.Unitat = component.Unitat;
        }

        public void ActualitzarComponent(Component c)
        {
            using var conn = _connectionFactory.CreateOpenConnection();
            using var tran = conn.BeginTransaction();

            try
            {
                _database.ExecuteNonQuery(
                    conn,
                    @"UPDATE Item
              SET it_nom   = :nom,
                  it_desc  = :descripcio,
                  it_stock = :stock,
                  it_foto  = :foto
              WHERE it_codi = :codi",
                    new[]
                    {
                new OracleParameter("nom", c.Nom),
                new OracleParameter("descripcio", c.Descripcio ?? string.Empty),
                new OracleParameter("stock", c.Stock),
                new OracleParameter("foto", c.Foto ?? (object)DBNull.Value),
                new OracleParameter("codi", c.Codi)
                    },
                    tran
                );

                _database.ExecuteNonQuery(
                    conn,
                    @"UPDATE Component
              SET cm_codi_fabricant = :fabricant
              WHERE cm_codi = :codi",
                    new[]
                    {
                new OracleParameter("fabricant", c.CodiFabricant),
                new OracleParameter("codi", c.Codi)
                    },
                    tran
                );

                _database.ExecuteNonQuery(
                    conn,
                    "DELETE FROM Prov_Comp WHERE pc_cm_codi = :codiComp",
                    new[] { new OracleParameter("codiComp", c.Codi) },
                    tran
                );

                foreach (var kv in c.ObtenirProveidors())
                {
                    _database.ExecuteNonQuery(
                        conn,
                        @"INSERT INTO Prov_Comp (pc_cm_codi, pc_pv_codi, pc_preu)
                  VALUES (:codiComp, :codiProv, :preu)",
                        new[]
                        {
                    new OracleParameter("codiComp", c.Codi),
                    new OracleParameter("codiProv", kv.CodiProveidor),
                    new OracleParameter("preu", kv.Preu)
                        },
                        tran
                    );
                }

                tran.Commit();   
            }
            catch
            {
                tran.Rollback();
                throw;
            }
        }





        public void EliminarComponent(int codi)
        {
            var c = ObtenirComponent(codi);
            if (c != null)
                _components.Remove(c);
        }


        public List<ComponentProveidor> ObtenirProveidorsComponent(int codiComponent)
        {
            var parameters = new[]
            {
        new OracleParameter("codiComponent", OracleDbType.Int32)
        {
            Value = codiComponent
        }
    };

            return _database.ExecuteQuery(
                @"SELECT pc_cm_codi,
                 pc_pv_codi,
                 pc_preu
          FROM Prov_Comp
          WHERE pc_cm_codi = :codiComponent",
                r => new ComponentProveidor
                {
                    CodiComponent = r.GetInt32(0),
                    CodiProveidor = r.GetInt32(1),
                    Preu = r.GetDecimal(2)
                },
                parameters   
            ).ToList();
        }







        //public ComponentProveidor ObtenirComponentProvaHardcoded(int idComponent)
        //{

        //    if (idComponent != 4)
        //        return null;

        //    return new ComponentProveidor
        //    {
        //        CodiComponent = 4,
        //        CodiProveidor = 1,
        //        Preu = 99.99m
        //    };
        //}




        // ===============================
        // PERSISTÈNCIA
        // ===============================

        //public void ValidarCanvis()
        //{
        //    using var conn = _connectionFactory.CreateOpenConnection();
        //    using var tran = conn.BeginTransaction();
        //    _database.ExecuteNonQuery(conn, "ALTER TRIGGER trg_pc_row DISABLE", null, null);
        //    _database.ExecuteNonQuery(conn, "ALTER TRIGGER trg_pc_stmt DISABLE", null, null);

        //    try
        //    {
        //        // Esborrem totes les relacions i components
        //        _database.ExecuteNonQuery(conn, "DELETE FROM Prov_Comp", null, tran);
        //        _database.ExecuteNonQuery(conn, "DELETE FROM Component", null, tran);
        //        _database.ExecuteNonQuery(conn, "DELETE FROM Item WHERE it_tipus = 'C'", null, tran);

        //        // Inserim novament cada component, el seu Item i les relacions amb proveïdors
        //        foreach (var c in _components)
        //        {
        //            if (c.Unitat == null)
        //                throw new InvalidOperationException($"Component {c.Codi} sense UnitatMesura");

        //            // Inserció a Item
        //            _database.ExecuteNonQuery(
        //                conn,
        //                InsertItemSql,
        //                new[]
        //                {
        //            new OracleParameter("codi", c.Codi),
        //            new OracleParameter("nom", c.Nom),
        //            new OracleParameter("descripcio", c.Descripcio),
        //            new OracleParameter("stock", c.Stock),
        //            new OracleParameter("foto", c.Foto ?? (object)DBNull.Value)
        //                },
        //                tran
        //            );

        //            // Inserció a Component
        //            _database.ExecuteNonQuery(
        //                conn,
        //                InsertComponentSql,
        //                new[]
        //                {
        //            new OracleParameter("codi", c.Codi),
        //            new OracleParameter("um", c.Unitat.Codi),
        //            new OracleParameter("fabricant", c.CodiFabricant),
        //            new OracleParameter("preu", c.PreuMig)
        //                },
        //                tran
        //            );

        //            // Inserim relacions a Prov_Comp per a cada proveïdor assignat
        //            foreach (var kvp in c.ObtenirProveidors())
        //            {
        //                //var prov = kvp.Key;
        //                //var preu = kvp.Value;
        //                _database.ExecuteNonQuery(
        //                    conn,
        //                    "INSERT INTO Prov_Comp (pc_cm_codi, pc_pv_codi, pc_preu) VALUES (:codiComp, :codiProv, :preu)",
        //                    new[]
        //                    {
        //                new OracleParameter("codiComp", c.Codi),
        //                new OracleParameter("codiProv", prov.GetCodi()),
        //                new OracleParameter("preu", preu)
        //                    },
        //                    tran
        //                );
        //            }
        //        }

        //        tran.Commit();
        //    }
        //    catch
        //    {
        //        tran.Rollback();
        //        throw;
        //    }
        //    finally
        //    {
        //        _database.ExecuteNonQuery(conn, "ALTER TRIGGER trg_pc_row ENABLE", null, null);
        //        _database.ExecuteNonQuery(conn, "ALTER TRIGGER trg_pc_stmt ENABLE", null, null);

        //    }
        //}


        public void DesferCanvis() => CarregarComponents();

        public void TancarCapa() => _components.Clear();

        // ===============================
        // MAPPERS
        // ===============================

        private static Component MapComponent(OracleDataReader r)
        {
            var unitat = new UnitatMesura(
                r.GetInt32(r.GetOrdinal("CM_UM_CODI")),
                r.GetString(r.GetOrdinal("UM_NOM"))
            );

            return new Component
            {
                Codi = r.GetInt32(r.GetOrdinal("IT_CODI")),
                Nom = r.GetString(r.GetOrdinal("IT_NOM")),
                Descripcio = r.IsDBNull(r.GetOrdinal("IT_DESC"))
                    ? string.Empty
                    : r.GetString(r.GetOrdinal("IT_DESC")),
                Stock = r.GetInt32(r.GetOrdinal("IT_STOCK")),
                Foto = GetNullableBytes(r, "IT_FOTO") ?? Array.Empty<byte>(),
                CodiFabricant = r.GetInt32(r.GetOrdinal("CM_CODI_FABRICANT")),
                PreuMig = r.GetDecimal(r.GetOrdinal("CM_PREU_MIG")),
                Unitat = unitat
            };
        }

        private static byte[]? GetNullableBytes(OracleDataReader r, string col)
        {
            int ord = r.GetOrdinal(col);
            return r.IsDBNull(ord) ? null : (byte[])r.GetValue(ord);
        }
    }
}

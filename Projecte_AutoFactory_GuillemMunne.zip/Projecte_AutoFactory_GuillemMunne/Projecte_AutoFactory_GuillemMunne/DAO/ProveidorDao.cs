using System;
using System.Collections.Generic;
using System.Linq;
using AutoFactory.DAO.Oracle;
using AutoFactory.IDAO;
using AutoFactory.Model;
using Oracle.ManagedDataAccess.Client;
using OracleDatabase = AutoFactory.DAO.Oracle.OracleDatabase;

namespace AutoFactory.DAO
{
    public sealed class ProveidorDao : IDAOProveidor
    {
        // ===============================
        // SQL
        // ===============================

        private const string SelectAllSql = @"
    SELECT
        p.pv_codi                    AS CODI,
        p.pv_cif                     AS CIF,
        p.pv_rao_social              AS RAO_SOCIAL,
        p.pv_persona_contacte        AS PERSONA_CONTACTE,
        p.pv_lin_adre_fac            AS LINIA_ADRECA_FACTURACIO,
        p.pv_telef_contacte                 AS TELEFON,

        m.mu_codi                    AS MUNICIPI_CODI,
        m.mu_nom                     AS MUNICIPI_NOM,

        pr.pr_codi                   AS PROVINCIA_CODI,
        pr.pr_nom                    AS PROVINCIA_NOM
    FROM PROVEIDOR p
    LEFT JOIN MUNICIPI m
        ON m.mu_codi = p.pv_mu_num
    LEFT JOIN PROVINCIA pr
        ON pr.pr_codi = m.mu_pr_codi
    ORDER BY p.pv_codi
";


        private const string InsertSql = @"
            INSERT INTO PROVEIDOR
                (PV_CODI, PV_CIF, PV_RAO_SOCIAL, PV_PERSONA_CONTACTE,
                 PV_LINIA_ADRECA_FACTURACIO, PV_TELEFON, PV_MUNICIPI)
            VALUES
                (:codi, :cif, :rao_social, :persona_contacte,
                 :linia_adreca_facturacio, :telefon, :municipi_codi)
        ";

        private const string DeleteAllSql = @"DELETE FROM PROVEIDOR";

        // ===============================
        // CAMPS
        // ===============================

        private readonly OracleDatabase _database;
        private List<Proveidor> _proveidors = new();

        // ===============================
        // CONSTRUCTOR
        // ===============================

        public ProveidorDao(OracleDatabase database)
        {
            _database = database ?? throw new ArgumentNullException(nameof(database));
            CarregarProveidors();
        }

        // ===============================
        // C�RREGA
        // ===============================

        public List<Proveidor> CarregarProveidors()
        {
            _proveidors = _database.ExecuteQuery(SelectAllSql, MapProveidor).ToList();
            return _proveidors;
        }

        public List<Proveidor> ObtenirTots()
        {
            return _proveidors;
        }

        public Proveidor ObtenirProveidor(int codi)
        {
            return _proveidors.FirstOrDefault(p => p.GetCodi() == codi);
        }

        // ===============================
        // CRUD EN MEM�RIA
        // ===============================

        public void Afegir(Proveidor proveidor)
        {
            if (proveidor == null)
                throw new ArgumentNullException(nameof(proveidor));

            _proveidors.Add(proveidor);
        }

        public void Actualitzar(Proveidor proveidor)
        {
            if (proveidor == null)
                throw new ArgumentNullException(nameof(proveidor));

            int index = _proveidors.FindIndex(p => p.GetCodi() == proveidor.GetCodi());
            if (index < 0) return;

            _proveidors[index] = proveidor;
        }

        public void Eliminar(int codi)
        {
            var p = _proveidors.FirstOrDefault(x => x.GetCodi() == codi);
            if (p != null)
                _proveidors.Remove(p);
        }

        // ===============================
        // PERSIST�NCIA
        // ===============================

        public void ValidarCanvis()
        {
            

            foreach (var p in _proveidors)
            {
                var parameters = new[]
                {
                    new OracleParameter("codi", p.GetCodi()),
                    new OracleParameter("cif", p.GetCif() ?? (object)DBNull.Value),
                    new OracleParameter("rao_social", p.GetRS() ?? (object)DBNull.Value),
                    new OracleParameter("persona_contacte", p.GetPersonaContacte() ?? (object)DBNull.Value),
                    new OracleParameter("linia_adreca_facturacio", p.GetLAF() ?? (object)DBNull.Value),
                    new OracleParameter("telefon", p.GetTelefonContacte()),
                    new OracleParameter(
                        "municipi_codi",
                        p.GetMunicipi()?.CodiMunicipi ?? (object)DBNull.Value
                    )
                };

                _database.ExecuteNonQuery(InsertSql, parameters);
            }
        }

        public void DesferCanvis()
        {
            CarregarProveidors();
        }

        public void TancarCapa()
        {
            _proveidors.Clear();
        }

        // ===============================
        // MAPPER
        // ===============================

        private static Proveidor MapProveidor(OracleDataReader r)
        {
            // ===== PROVINCIA (pot ser NULL) =====
            Provincia? provincia = null;
            if (!r.IsDBNull(r.GetOrdinal("PROVINCIA_CODI")))
            {
                int provCodi = r.GetInt32(r.GetOrdinal("PROVINCIA_CODI"));
                string provNom = r.IsDBNull(r.GetOrdinal("PROVINCIA_NOM"))
                    ? string.Empty
                    : r.GetString(r.GetOrdinal("PROVINCIA_NOM"));

                provincia = new Provincia(provCodi, provNom);
            }

            // ===== MUNICIPI (pot ser NULL) =====
            Municipi? municipi = null;
            if (!r.IsDBNull(r.GetOrdinal("MUNICIPI_CODI")))
            {
                int munCodi = r.GetInt32(r.GetOrdinal("MUNICIPI_CODI"));
                string munNom = r.IsDBNull(r.GetOrdinal("MUNICIPI_NOM"))
                    ? string.Empty
                    : r.GetString(r.GetOrdinal("MUNICIPI_NOM"));

                municipi = new Municipi(munCodi, munNom, provincia);
            }

            // ===== PROVEIDOR =====
            int codi = r.GetInt32(r.GetOrdinal("CODI"));

            string cif = r.IsDBNull(r.GetOrdinal("CIF"))
                ? string.Empty
                : r.GetString(r.GetOrdinal("CIF"));

            string raoSocial = r.IsDBNull(r.GetOrdinal("RAO_SOCIAL"))
                ? string.Empty
                : r.GetString(r.GetOrdinal("RAO_SOCIAL"));

            string personaContacte = r.IsDBNull(r.GetOrdinal("PERSONA_CONTACTE"))
                ? string.Empty
                : r.GetString(r.GetOrdinal("PERSONA_CONTACTE"));

            string liniaAdreca = r.IsDBNull(r.GetOrdinal("LINIA_ADRECA_FACTURACIO"))
                ? string.Empty
                : r.GetString(r.GetOrdinal("LINIA_ADRECA_FACTURACIO"));

            string telefon = r.IsDBNull(r.GetOrdinal("TELEFON"))
    ? string.Empty
    : r.GetString(r.GetOrdinal("TELEFON"));


            return new Proveidor(
                codi,
                cif,
                raoSocial,
                personaContacte,
                liniaAdreca,
                int.Parse(telefon),
                municipi
            );
        }
    }
}

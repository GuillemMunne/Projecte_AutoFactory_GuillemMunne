using System;
using System.Collections.Generic;
using System.Linq;
using AutoFactory.DAO.Oracle;
using AutoFactory.IDAO;
using AutoFactory.Model;
using Oracle.ManagedDataAccess.Client;
using OracleDatabase = AutoFactory.DAO.Oracle.OracleDatabase;

namespace AutoFactory.DAO
{
    public sealed class MunicipiDao : IDAOMunicipi
    {
        // ===============================
        // SQL
        // ===============================

        private const string SelectAllSql = @"
            SELECT
                m.mu_codi        AS CODI,
                m.mu_nom         AS NOM,
                p.pr_codi        AS PROVINCIA_CODI,
                p.pr_nom         AS PROVINCIA_NOM
            FROM MUNICIPI m
            JOIN PROVINCIA p
                ON p.pr_codi = m.mu_pr_codi
            ORDER BY m.mu_codi
        ";

        private const string InsertSql = @"
            INSERT INTO MUNICIPI (MU_CODI, MU_NOM, MU_PR_CODI)
            VALUES (:codi, :nom, :provincia_codi)
        ";

        private const string DeleteAllSql = @"DELETE FROM MUNICIPI";

        // ===============================
        // CAMPS
        // ===============================

        private readonly OracleDatabase _database;
        private List<Municipi> _municipis = new();

        // ===============================
        // CONSTRUCTOR
        // ===============================

        public MunicipiDao(OracleDatabase database)
        {
            _database = database ?? throw new ArgumentNullException(nameof(database));
            CarregarMunicipi(); // ?? nom segons la interf�cie
        }

        // ===============================
        // IMPLEMENTACI� DE LA INTERF�CIE
        // ===============================

        public List<Municipi> CarregarMunicipi()
        {
            _municipis = _database.ExecuteQuery(SelectAllSql, MapMunicipi).ToList();
            return _municipis;
        }

        public Municipi ObtenirMunicipi(int codi)
        {
            return _municipis.FirstOrDefault(m => m.CodiMunicipi == codi);
        }

        public void TancarCapa()
        {
            _municipis.Clear();
        }

        // ===============================
        // EXTRES (no obligats per la interf�cie)
        // ===============================

        public IReadOnlyList<Municipi> ObtenirTots()
        {
            return _municipis;
        }

        public void Afegir(Municipi municipi)
        {
            if (municipi == null)
                throw new ArgumentNullException(nameof(municipi));

            _municipis.Add(municipi);
        }

        public void Actualitzar(Municipi municipi)
        {
            if (municipi == null)
                throw new ArgumentNullException(nameof(municipi));

            int index = _municipis.FindIndex(m => m.CodiMunicipi == municipi.CodiMunicipi);
            if (index < 0) return;

            _municipis[index] = municipi;
        }

        public void Eliminar(int codi)
        {
            var municipi = _municipis.FirstOrDefault(m => m.CodiMunicipi == codi);
            if (municipi != null)
                _municipis.Remove(municipi);
        }

        public void ValidarCanvis()
        {
            _database.ExecuteNonQuery(DeleteAllSql);

            foreach (var municipi in _municipis)
            {
                var parameters = new[]
                {
                    new OracleParameter("codi", municipi.CodiMunicipi),
                    new OracleParameter("nom", municipi.Nom),
                    new OracleParameter("provincia_codi", municipi.Provincia.Codi)
                };

                _database.ExecuteNonQuery(InsertSql, parameters);
            }
        }

        public void DesferCanvis()
        {
            CarregarMunicipi();
        }

        // ===============================
        // MAPPER
        // ===============================

        private static Municipi MapMunicipi(OracleDataReader r)
        {
            int provinciaCodi = r.GetInt32(r.GetOrdinal("PROVINCIA_CODI"));
            string provinciaNom = r.GetString(r.GetOrdinal("PROVINCIA_NOM"));
            var provincia = new Provincia(provinciaCodi, provinciaNom);

            int codi = r.GetInt32(r.GetOrdinal("CODI"));
            string nom = r.GetString(r.GetOrdinal("NOM"));

            return new Municipi(codi, nom, provincia);
        }
    }
}

﻿using AutoFactory.DAO.Oracle;
using Oracle.ManagedDataAccess.Client;
using Projecte_AutoFactory_GuillemMunne.MODEL;
using System.Collections.Generic;
using System.Data;
using OracleDatabase = AutoFactory.DAO.Oracle.OracleDatabase;

public class ProveidorComponentDao
{
    private readonly OracleDatabase _dataBase;
    private List<ProveidorComponentItem> _proveidorsComponents;

    public ProveidorComponentDao(OracleDatabase dataBase)
    {
         _dataBase=dataBase ;

    }



    public IReadOnlyList<ProveidorComponentItem> ObtenirProveidorsPerComponent(int codiComponent)
    {
        string sql = @"SELECT 
            pc.PC_PV_CODI,
            p.PV_RAO_SOCIAL,
            pc.PC_PREU
        FROM PROV_COMP pc
        JOIN PROVEIDOR p 
            ON p.PV_CODI = pc.PC_PV_CODI  
        WHERE PC.PC_CM_CODI= :codi
    ";



        var parameters =
        new[]
        {
        new OracleParameter
        {
            ParameterName = "codi",              // SENSE :
            OracleDbType = OracleDbType.Int32, // PC_CM_CODI és NUMBER
            Value = codiComponent
        }
         };

        return _dataBase.ExecuteQuery(
            sql,
            reader => new ProveidorComponentItem
            {
                CodiProveidor=reader.GetInt32(0),
                NomProveidor = reader.GetString(1),
                Preu = reader.GetDecimal(2)
            },
            parameters
        );
    }



    //public List<ProveidorComponentItem> ObtenirProveidorsPerComponent_SenseParametre()
    //{
    //    var resultat = new List<ProveidorComponentItem>();

    //    using (var conn = _connectionFactory.CreateOpenConnection())
    //    using (var cmd = new OracleCommand())
    //    {
    //        cmd.Connection = conn;
    //        cmd.CommandType = CommandType.Text;

    //        cmd.CommandText = @"
    //        SELECT 
    //            PC_PV_CODI,
    //            PC_PREU
    //        FROM PROV_COMP 
            
    //        WHERE PC_CM_CODI = 4
    //    ";

    //        using (var reader = cmd.ExecuteReader())
    //        {
    //            while (reader.Read())
    //            {
    //                resultat.Add(new ProveidorComponentItem
    //                {
    //                    NomProveidor = reader.GetString(0),
    //                    Preu = reader.GetDecimal(1)
    //                });
    //            }
    //        }
    //    }

    //    return resultat;
    //}


}

using System.Collections.Generic;
using AutoFactory.Model;

namespace AutoFactory.IDAO
{
    public interface IDAOProducte
    {
        // ===============================
        // C�RREGA
        // ===============================

        List<Producte> CarregarProductes();

        // ===============================
        // CRUD EN MEM�RIA
        // ===============================

        IReadOnlyList<Producte> ObtenirTots();
        Producte? ObtenirProducte(int codiProducte);

        void AfegirProducte(Producte producte);
        void EliminarProducte(int codiProducte);
        void ModificarProducte(Producte producte);

        // ===============================
        // PERSIST�NCIA
        // ===============================

        void ValidarCanvis();
        void DesferCanvis();
        void TancarCapa();
    }
}

using System.Collections.Generic;
using AutoFactory.Model;

namespace AutoFactory.IDAO
{
    public interface IDAOComponent
    {
        // ===============================
        // C�RREGA
        // ===============================
        List<Component> CarregarComponents();
        IReadOnlyList<Component> ObtenirTots();
        Component? ObtenirComponent(int codiComponent);

        // ===============================
        // CRUD EN MEM�RIA
        // ===============================
        void AfegirComponent(Component component);
        void ModificarComponent(Component component);
        void EliminarComponent(int codiComponent);

        // ===============================
        // RELACIONS
        // ===============================
        List<ComponentProveidor> ObtenirProveidorsComponent(int codiComponent);

        // ===============================
        // PERSIST�NCIA
        // ===============================
        //void ValidarCanvis();
        void DesferCanvis();
        void TancarCapa();
    }
}

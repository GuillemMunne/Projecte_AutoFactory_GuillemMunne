﻿using AutoFactory.DAO;
using AutoFactory.DAO.Oracle;
using AutoFactoryProjecte.Finestres.FinestreMainWindow;
using ProjecteAutoFactory.Finestres.FinestreMainWindow;
using ProjecteAutoFactory.Finestres.FinestreNormal;
using System;
using System.Windows;
using System.Windows.Controls;

namespace ProjecteAutoFactory
{
   
    public partial class MainWindow : Window
    {
        private OracleDatabase _database;
        private DAOComponent _daoComponent;
        private ProducteDao _producteDao;
        private ProveidorDao _proveidorDao;
        private MunicipiDao _municipiDao;
        private ProvinciaDao _provinciaDao;
        private UnitatMesuraDao _unitatMesuraDao;
        private ProveidorComponentDao _proveidorComponentDao;
        public MainWindow()
        {
            InitializeComponent();
            InicialitzarDatabase();
        }
        private void InicialitzarDatabase()
        {
            string connectionString =
                "User Id=alumne;" +
"Password=alumne;" +
"Data Source=(DESCRIPTION=" +
"(ADDRESS=(PROTOCOL=TCP)(HOST=127.0.0.1)(PORT=1521))" +
"(CONNECT_DATA=(SERVICE_NAME=XEPDB1))" +
");";



            var connectionFactory = new OracleConnectionFactory(connectionString);
            _database = new OracleDatabase(connectionFactory);

            _municipiDao = new MunicipiDao(_database);
            _provinciaDao = new ProvinciaDao(_database);
            _unitatMesuraDao = new UnitatMesuraDao(_database);
            
            _proveidorDao = new ProveidorDao(_database);
            _daoComponent = new DAOComponent(_database,connectionFactory,_proveidorDao);
            _producteDao = new ProducteDao(_database, connectionFactory,_daoComponent,_proveidorDao);
            _proveidorComponentDao = new ProveidorComponentDao(_database);


        }
        private bool temaOscuro = false;

        private Button botonSeleccionado;

        private void BtnCambiarTema_Click(object sender, RoutedEventArgs e)
        {
            temaOscuro = !temaOscuro;

            Application.Current.Resources.MergedDictionaries.Clear();

            var diccionario = new ResourceDictionary();
            diccionario.Source = new Uri(
                temaOscuro ? "src/Themes/Dark.xaml" : "src/Themes/Light.xaml", UriKind.Relative);

            Application.Current.Resources.MergedDictionaries.Add(diccionario);

            if (botonSeleccionado != null)
            {
                botonSeleccionado.Style = TryFindResource("MainButtonMenuSelected") as Style;
            }
        }

        private void clickGestioProductes(object sender, RoutedEventArgs e)
        {
            SeleccioFinestra(new GestioProductes(_producteDao,_daoComponent), btnGestioProductes);
        }

        private void clickComponentsPrimaris(object sender, RoutedEventArgs e)
        {
            SeleccioFinestra(new GestioComponents(_daoComponent,_proveidorDao,_producteDao,_proveidorComponentDao,_unitatMesuraDao), btnComponentsPrimaris);
        }

        private void clickProveidors(object sender, RoutedEventArgs e)
        {
            SeleccioFinestra(new Proveidors(_proveidorDao,_daoComponent), btnProveidors);
        }
        private void clickFinestraAjuda(object sender, RoutedEventArgs e)
        {
            SeleccioFinestra(new Ajuda(), btnFinestraAjuda);
        }

        private void clickLogin(object sender, RoutedEventArgs e)
        {
            var login = new Login();
            login.Show();
            this.Close();
        }
        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SeleccioFinestra(new GestioProductes(_producteDao, _daoComponent), btnGestioProductes);
        }

        private void AccedirInforme(object sender, RoutedEventArgs e)
        {

        }

        private void SeleccioFinestra(UserControl seccio, Button boto)
        {
            FinestraMostrada.Content = seccio;

            if (ReferenceEquals(botonSeleccionado, boto))
            {
                return;
            }

            DeseleccionarBoton();
            SeleccionarBoton(boto);
        }

        private void SeleccionarBoton(Button boton)
        {
            if (botonSeleccionado != null)
            {
                botonSeleccionado.Style = TryFindResource("MainButtonMenu") as Style;
            }

            boton.Style = TryFindResource("MainButtonMenuSelected") as Style;
            botonSeleccionado = boton;
        }

        private void DeseleccionarBoton()
        {
            if (botonSeleccionado != null)
            {
                botonSeleccionado.Style = TryFindResource("MainButtonMenu") as Style;
            }
            botonSeleccionado = null;
        }


    }
}
